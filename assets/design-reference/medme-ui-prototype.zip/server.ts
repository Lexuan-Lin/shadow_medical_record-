/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Set up larger limits for body parser to accept base64 image data
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Lazy initialised Gemini client to prevent crashes if key is not yet set
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    throw new Error("GEMINI_API_KEY is not configured in Secrets / environment variables.");
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Structured output schema for medical OCR report parsing
const ocrSchema = {
  type: Type.OBJECT,
  properties: {
    date: { type: Type.STRING, description: "就诊日期，格式 YYYY-MM-DD，若未提及则返回合理估计" },
    hospital: { type: Type.STRING, description: "医院名称，如：北京协和医院" },
    department: { type: Type.STRING, description: "就诊科室，如：消化内科、心血管内科" },
    category: { type: Type.STRING, description: "类别，必须是以下之一: outpatient (门诊病历), lab (化验单), imaging (检查影像), prescription (药方处方)" },
    title: { type: Type.STRING, description: "事件标题，如：血常规化验报告、门诊复诊记录" },
    summary: { type: Type.STRING, description: "主要结论、临床诊断或主要症状的简短摘要" },
    labIndicators: {
      type: Type.ARRAY,
      description: "化验单指标列表（仅在 category 为 lab 时提供）",
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "指标中文名，如：甘油三酯" },
          abbr: { type: Type.STRING, description: "英文简称，如：TG" },
          value: { type: Type.STRING, description: "检测数值" },
          unit: { type: Type.STRING, description: "测量单位，如：mmol/L" },
          referenceRange: { type: Type.STRING, description: "参考区间，如：0.45 - 1.70" },
          status: { type: Type.STRING, description: "状态，必须是: normal (正常), high (偏高), low (偏低)" }
        },
        required: ["name", "value", "unit", "referenceRange", "status"]
      }
    },
    prescriptions: {
      type: Type.ARRAY,
      description: "开具的药品列表（仅在 category 为 prescription 或病历中包含药方时提供）",
      items: {
        type: Type.OBJECT,
        properties: {
          drugName: { type: Type.STRING, description: "药品名称" },
          specification: { type: Type.STRING, description: "规格，如：0.25g * 24s" },
          dosage: { type: Type.STRING, description: "用法用量，如：一次1片，一日3次" },
          quantity: { type: Type.STRING, description: "开药数量，如：2盒" }
        },
        required: ["drugName", "dosage"]
      }
    },
    imagingResult: {
      type: Type.OBJECT,
      description: "影像学检查细节（仅在 category 为 imaging 时提供）",
      properties: {
        finding: { type: Type.STRING, description: "检查所见/描述" },
        conclusion: { type: Type.STRING, description: "诊断意见/提示" }
      }
    },
    aiInterpretation: { type: Type.STRING, description: "以专业、通俗、温暖、支持性的口纹（约200字，中文），针对中国患者，详细解读报告关键指标或诊断结论的意义，解答可能存在的疑问，并给出针对性的日常调理与饮食建议。" }
  },
  required: ["date", "hospital", "department", "category", "title", "summary", "aiInterpretation"]
};

// HEALTH CHECK ENDPOINT
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// CONFIG CHECK ENDPOINT (Check if API key is loaded)
app.get("/api/config", (req, res) => {
  const key = process.env.GEMINI_API_KEY;
  const isLoaded = !!key && key !== "MY_GEMINI_API_KEY" && key.trim() !== "";
  res.json({ hasApiKey: isLoaded });
});

// OCR API ENDPOINT
app.post("/api/ocr", async (req, res) => {
  try {
    const { text, image } = req.body;
    const ai = getGeminiClient();

    let contents: any[] = [];

    const prompt = `你是一个专业的医学报告 OCR 解析助手。
请分析用户提供的医学图像（base64）或报告文本，提取出结构化的就诊与体检信息。
提取规则：
1. 识别就诊日期，格式必须是 YYYY-MM-DD。如果报告中没有明确日期，推测一个合理的，或者使用当前日期 2026-07-06。
2. 识别就诊医院，如“北京协和医院”，如果识别不到，默认使用“未标注医院”。
3. 识别科室，如“消化内科”、“内科”，如果识别不到，默认使用“综合内科”。
4. 分类分类：根据报告类型，必须从 outpatient（门诊病历）, lab（化验单）, imaging（检查影像）, prescription（药方处方）中选择一个。
5. 提取标题：如“血常规化验单”、“腹部超声检查报告”等。
6. 提供简短的诊断/主要结论总结。
7. 如果是化验单（lab），提取每一个化验指标（包含指标名、英文简称、数值、单位、参考区间、状态 high/low/normal）。
8. 如果有开具处方（prescription），提取药品名称、规格、用法用量、数量。
9. 如果是影像报告（imaging），提取“检查所见”和“诊断意见”。
10. 生成“医我智析” (aiInterpretation)：用温暖、支持性的口吻解释此报告。不要使用冰冷的医学术语，请告诉患者这说明了什么，需要注意什么，饮食生活上有何建议。`;

    contents.push(prompt);

    if (image && image.base64 && image.mimeType) {
      contents.push({
        inlineData: {
          mimeType: image.mimeType,
          data: image.base64
        }
      });
    }

    if (text) {
      contents.push(`报告文本：\n${text}`);
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        responseMimeType: "application/json",
        responseSchema: ocrSchema,
        temperature: 0.1
      }
    });

    const parsedJson = JSON.parse(response.text || "{}");
    res.json({ success: true, data: parsedJson });
  } catch (error: any) {
    console.error("OCR API error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// HEALTH CHAT API ENDPOINT
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, timelineEvents } = req.body;
    const ai = getGeminiClient();

    const systemInstruction = `你叫“医我” (MedMe) 专属健康助手，是由 Tauri 本地高安全性保险箱驱动的个人健康顾问。
用户是一个中国患者，他们通过 OCR 整理了自己的个人病历时间线 (Lifeline)。
以下是用户已上传并本地强加密的所有医疗事件数据 (Timeline Events)：
${JSON.stringify(timelineEvents, null, 2)}

请结合以上所有病历历史数据，回答用户的咨询。
回答规范：
1. 说话风格必须专业、温暖、充满人文关怀、用通俗易懂的语言解答患者的疑问。
2. 绝不能代替临床医生下诊断。如遇到紧急或严重情况，提醒用户线下就医。
3. 重点结合他们已有的病历数据！例如：“我看到您在4月份的血常规里，白细胞略微偏高...”。
4. 使用标准 Markdown 格式排版，增加可读性。`;

    const contents = messages.map((m: any) => ({
      role: m.role === "user" ? "user" : "model",
      parts: [{ text: m.content }]
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.5
      }
    });

    res.json({ success: true, text: response.text });
  } catch (error: any) {
    console.error("Chat API error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

async function startServer() {
  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
