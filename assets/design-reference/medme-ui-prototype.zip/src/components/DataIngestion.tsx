/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from "react";
import { 
  UploadCloud, 
  FileText, 
  Activity, 
  Image as ImageIcon, 
  Pill, 
  ShieldCheck, 
  Lock, 
  EyeOff, 
  Zap, 
  Sparkles,
  RefreshCw,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { mockTemplates, MockTemplate } from "./DocumentMockTemplates";
import { TimelineEvent } from "../types";

interface DataIngestionProps {
  onAddEvent: (event: TimelineEvent) => void;
  setActiveTab: (tab: string) => void;
  hasApiKey: boolean;
}

export default function DataIngestion({ onAddEvent, setActiveTab, hasApiKey }: DataIngestionProps) {
  const [inputText, setInputText] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [processStep, setProcessStep] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Background steps for Tauri "silent backend processing" visualization
  const processingSteps = [
    "启动沙盒隔离保护，确保数据不泄露...",
    "本地数据合规审查与文字提取进行中...",
    "AI 静默进行指标翻译与专业临床归档...",
    "生成暖心版'医我智析'患者专属指南...",
    "采用 AES-256 将报告加密写入本地 Vault..."
  ];

  const simulateProcessing = (onDone: () => void) => {
    setIsProcessing(true);
    setProcessStep(0);
    setErrorMessage(null);

    const interval = setInterval(() => {
      setProcessStep((prev) => {
        if (prev >= processingSteps.length - 1) {
          clearInterval(interval);
          setTimeout(() => {
            setIsProcessing(false);
            onDone();
          }, 800);
          return prev;
        }
        return prev + 1;
      });
    }, 1200);
  };

  // Handles real OCR / parsing by calling /api/ocr
  const handleOcrRequest = async (payload: { text?: string; image?: { base64: string; mimeType: string } }) => {
    if (!hasApiKey) {
      // No API key - fallback to instant beautiful simulation (mock parsing) to keep UI highly functional
      simulateProcessing(() => {
        // Find if they selected a template, otherwise generate a generic timeline event
        const matchingTemplate = mockTemplates.find(t => t.rawText === payload.text);
        
        let mockParsedEvent: TimelineEvent;

        if (matchingTemplate) {
          mockParsedEvent = createMockEventFromTemplate(matchingTemplate);
        } else {
          // Generate realistic outpatient event from pasted text
          mockParsedEvent = {
            id: `event-${Date.now()}`,
            date: "2026-07-06",
            hospital: "本地智能模拟诊所",
            department: "综合内科",
            category: "outpatient" as any,
            title: "自由文本 OCR 解析病历",
            summary: payload.text ? payload.text.substring(0, 30) + "..." : "体检报告汇总",
            rawText: payload.text || "上传的病历照片内容",
            aiInterpretation: "（演示环境模拟解析）我们对您输入的文字进行了本地大模型归纳：检测到您的主诉症状。由于目前为【本地演示模式】，大模型 OCR 无法真实联网。请在 AI Studio 右上角 Settings > Secrets 中配置您的 GEMINI_API_KEY，即可体验百分百精准的协和、华西、瑞金医院全套病历/化验单图像静默智能识别与解析服务！",
            isEncrypted: true
          };
        }

        onAddEvent(mockParsedEvent);
        setActiveTab("timeline");
      });
      return;
    }

    // Has API key - perform REAL full-stack Gemini OCR parsing!
    setIsProcessing(true);
    setProcessStep(0);
    setErrorMessage(null);

    // Dynamic visualization step timer to look ultra smooth
    const stepInterval = setInterval(() => {
      setProcessStep(prev => (prev < processingSteps.length - 1 ? prev + 1 : prev));
    }, 1800);

    try {
      const response = await fetch("/api/ocr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const result = await response.json();
      clearInterval(stepInterval);

      if (result.success && result.data) {
        const parsedData = result.data;
        const newEvent: TimelineEvent = {
          id: `event-${Date.now()}`,
          date: parsedData.date || "2026-07-06",
          hospital: parsedData.hospital || "未命名医院",
          department: parsedData.department || "综合科室",
          category: parsedData.category,
          title: parsedData.title || "导入的医疗报告",
          summary: parsedData.summary || "解析完成",
          rawText: payload.text || "图片 OCR 原始数据",
          labIndicators: parsedData.labIndicators,
          prescriptions: parsedData.prescriptions,
          imagingResult: parsedData.imagingResult,
          isEncrypted: true,
          aiInterpretation: parsedData.aiInterpretation
        };

        onAddEvent(newEvent);
        setIsProcessing(false);
        setActiveTab("timeline");
      } else {
        throw new Error(result.error || "OCR 解析失败");
      }
    } catch (err: any) {
      clearInterval(stepInterval);
      setIsProcessing(false);
      setErrorMessage(err.message || "大模型 OCR 服务不可用，请检查网络或 Secrets 配置。");
    }
  };

  const handleTemplateClick = (template: MockTemplate) => {
    setInputText(template.rawText);
    // Auto-parse the template for instant beautiful pipeline simulation & presentation
    handleOcrRequest({ text: template.rawText });
  };

  const handleRawTextSubmit = () => {
    if (!inputText.trim()) return;
    handleOcrRequest({ text: inputText });
  };

  // Convert uploaded image file to Base64 to support real image uploading
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(",")[1];
      handleOcrRequest({
        image: {
          base64: base64,
          mimeType: file.type
        },
        text: `【用户上传的图像文件：${file.name}】`
      });
    };
    reader.onerror = () => {
      setErrorMessage("读取文件失败，请重试");
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setErrorMessage("目前仅支持导入 JPG、PNG 等医学报告图像格式。");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(",")[1];
      handleOcrRequest({
        image: {
          base64: base64,
          mimeType: file.type
        },
        text: `【拖入的图像文件：${file.name}】`
      });
    };
    reader.readAsDataURL(file);
  };

  // Helper mapping templates into timeline structures in simulation mode
  const createMockEventFromTemplate = (template: MockTemplate): TimelineEvent => {
    if (template.id === "template-cbc") {
      return {
        id: "event-cbc",
        date: "2026-04-12",
        hospital: "北京协和医院",
        department: "消化内科",
        category: "lab" as any,
        title: "血常规检验报告单",
        summary: "白细胞及中性粒细胞计数轻度偏高，提示细菌性感染可能。",
        rawText: template.rawText,
        labIndicators: [
          { name: "白细胞计数", abbr: "WBC", value: "11.4", unit: "10^9/L", referenceRange: "4.0 - 10.0", status: "high" },
          { name: "红细胞计数", abbr: "RBC", value: "4.85", unit: "10^12/L", referenceRange: "4.3 - 5.8", status: "normal" },
          { name: "血红蛋白", abbr: "HGB", value: "142", unit: "g/L", referenceRange: "130 - 175", status: "normal" },
          { name: "血小板计数", abbr: "PLT", value: "210", unit: "10^9/L", referenceRange: "100 - 300", status: "normal" },
          { name: "中性粒细胞百分比", abbr: "NEUT%", value: "78.5", unit: "%", referenceRange: "50.0 - 70.0", status: "high" },
          { name: "淋巴细胞百分比", abbr: "LYMPH%", value: "15.2", unit: "%", referenceRange: "20.0 - 40.0", status: "low" }
        ],
        isEncrypted: true,
        aiInterpretation: `【医我智析 • 协和专家报告解读】\n\n1. **关于白细胞 (WBC) 与中性粒细胞 (NEUT%) 偏高**：这两个指标通常是身体的“免疫哨兵”。它们偏高表明体内有轻微的**细菌性发炎或感染**（结合主诉通常是胃肠炎、感冒等）。\n2. **淋巴细胞比率 (LYMPH%) 略低**：这是由于中性粒细胞比例升高导致的相对比例降低，不需要额外担心。\n3. **日常建议**：近期建议多喝温开水，保持充足睡眠，给免疫系统减轻压力。饮食宜清淡，避免辛辣油腻。如伴发热，请及时就医。`
      };
    } else if (template.id === "template-gastritis") {
      return {
        id: "event-gastritis",
        date: "2026-05-18",
        hospital: "四川大学华西医院",
        department: "消化内科",
        category: "outpatient" as any,
        title: "门诊电子病历记录",
        summary: "急性胃黏膜病变（急性胃炎）伴胃食管反流，由于进食辛辣刺激加重。",
        rawText: template.rawText,
        prescriptions: [
          { drugName: "奥美拉唑钠肠溶片", specification: "20mg * 14片", dosage: "口服，每日1次，每次1片(20mg)，晨起空腹", quantity: "1盒" },
          { drugName: "铝碳酸镁片 (达喜)", specification: "1.0g * 20片", dosage: "口服，一日3次，一次1片，餐后1小时嚼服", quantity: "2盒" }
        ],
        isEncrypted: true,
        aiInterpretation: `【医我智析 • 华西胃肠病病历解读】\n\n1. **急性胃粘膜损伤的原因**：患者因高强度工作、劳累以及熬夜导致胃粘膜屏障脆弱。再次受到四川辛辣油腻火锅的强烈刺激，瞬间引发急性胃炎及反流。\n2. **用药核心点**：\n   - **奥美拉唑**是强效抑酸药，晨起空腹吃能最大程度抑制白天的胃酸分泌，保护胃黏膜。\n   - **达喜**可以快速中和胃酸并吸附胆汁，嚼服效果最好，餐后一小时是胃酸分泌高峰，此时服用能迅速缓解灼痛。\n3. **养胃建议**：建议未来1周遵循“流质、温和”饮食。多喝小米粥、面条，严格禁酒、禁辣、禁冰水。多睡觉，胃黏膜在睡眠时自我修复最快。`
      };
    } else if (template.id === "template-ultrasound") {
      return {
        id: "event-ultrasound",
        date: "2026-06-05",
        hospital: "上海交通大学医学院附属瑞金医院",
        department: "体检中心",
        category: "imaging" as any,
        title: "腹部超声检查报告",
        summary: "轻度至中度脂肪肝，胆、胰、脾超声扫查未见异常。",
        rawText: template.rawText,
        imagingResult: {
          finding: "肝脏形态正常，包膜光整，内回声前段增强，后段衰减，管道结构显示欠清。胆囊、胰腺、脾脏大小形态未见明显异常。",
          conclusion: "1. 脂肪肝 (轻-中度)。\n2. 胆、胰、脾声像图未见明显异常。"
        },
        isEncrypted: true,
        aiInterpretation: `【医我智析 • 瑞金超声体检解读】\n\n1. **什么是脂肪肝（轻-中度）**：简单来说，就是肝脏细胞里的“油”稍微有点多。由于前段回声增强后段衰减，超声波穿透受阻，这是典型的脂肪沉积声像。\n2. **它是可逆的吗**：**完全可逆！** 轻中度脂肪肝通常不需要吃药，它是由于长期缺乏运动、高脂饮食或饮酒导致的脂肪蓄积。只要进行科学的体重管理，就能100%恢复健康。\n3. **逆转方案**：\n   - **饮食**：控制晚餐碳水化合物摄入，减少糖分及动物内脏摄入。增加优质蛋白（鸡胸肉、鱼肉）和绿叶菜。\n   - **运动**：每周进行150分钟以上的中等强度有氧运动（如快走、慢跑、羽毛球），使心率达到120次/分以上，坚持3个月复查超声，会有惊喜！`
      };
    } else {
      return {
        id: "event-rx",
        date: "2026-06-25",
        hospital: "中山大学附属第一医院",
        department: "心血管内科",
        category: "prescription" as any,
        title: "心血管内科门诊处方单",
        summary: "原发性高血压 2级（中危），开具联合降压药控制血压。",
        rawText: template.rawText,
        prescriptions: [
          { drugName: "苯磺酸氨氯地平片（络活喜）", specification: "5mg * 7片", dosage: "口服，一日1次，一次1片，晨起空腹", quantity: "4盒" },
          { drugName: "琥珀酸美托洛尔缓释片（倍他乐克）", specification: "47.5mg * 7片", dosage: "口服，一日1次，一次1片", quantity: "4盒" }
        ],
        isEncrypted: true,
        aiInterpretation: `【医我智析 • 中山一院高血压药方指导】\n\n1. **为什么开具两种药**：络活喜是地平类降压药，主要通过扩张血管降压；倍他乐克是β受体阻滞剂，能减缓心率、降低心肌耗氧量。联合用药是目前高血压治疗的金标准，能够协同增效、抵消副作用。\n2. **安全服药规范**：\n   - **络活喜**：降压平稳，由于每天吃1次，晨起空腹服用最容易坚持。部分人初期可能出现轻度下肢水肿，通常可耐受。\n   - **倍他乐克缓释片**：**千万不能嚼碎！** 必须整片吞服，否则会破坏缓释技术导致药效过快释放。\n3. **关键提醒**：千万不能觉得“头不晕了”就擅自停药或减药！血压波动对靶器官（心、脑、肾）的伤害比持续高血压更大。每天早晚测一次血压并记录，低盐低钠饮食。`
      };
    }
  };

  return (
    <div className="flex-1 flex flex-col h-screen overflow-hidden bg-slate-50 text-slate-800 font-sans">
      
      {/* Header */}
      <div className="border-b border-slate-200 bg-white p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <UploadCloud className="w-6 h-6 text-blue-600" />
          病历大模型 OCR 导入
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-500 font-normal">
            Silent OCR Engine
          </span>
        </h1>
        <p className="text-slate-500 text-xs mt-1">
          将医院开具的纸质病历、血液化验单、超声影像报告拍照或复制文字上传。后台静默处理、打破数据孤岛、自动结构化合并。
        </p>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
        {isProcessing ? (
          /* SILENT PROCESSING PIPELINE ANIMATION (用户无感知后台静默处理的华丽大屏展现) */
          <div className="max-w-2xl mx-auto h-[450px] flex flex-col justify-center items-center">
            <div className="relative mb-8">
              {/* Outer rotating pulse circle */}
              <div className="w-24 h-24 rounded-3xl border-2 border-blue-500/20 flex items-center justify-center animate-pulse"></div>
              {/* Inner rotating circle */}
              <div className="absolute inset-2 rounded-2xl border-t-2 border-r-2 border-blue-600 animate-spin flex items-center justify-center"></div>
              {/* Center Lock icon */}
              <div className="absolute inset-0 flex items-center justify-center">
                <Lock className="w-7 h-7 text-blue-600" />
              </div>
            </div>

            <div className="text-center space-y-4 w-full">
              <h3 className="text-lg font-bold text-slate-900 tracking-tight flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 text-blue-600 animate-bounce" />
                后台静默大模型处理中...
              </h3>
              <p className="text-slate-500 text-xs max-w-sm mx-auto leading-relaxed">
                Tauri 静默数据处理引擎正在沙箱中处理数据。不保存任何数据于云端服务器，保障绝对隐私。
              </p>

              {/* Steps Progress Checklist */}
              <div className="max-w-md mx-auto bg-white border border-slate-200 rounded-xl p-5 text-left space-y-3.5 shadow-sm">
                {processingSteps.map((step, idx) => {
                  const isCurrent = processStep === idx;
                  const isDone = processStep > idx;
                  
                  return (
                    <div 
                      key={idx} 
                      className={`flex items-center gap-3 text-xs transition-opacity duration-300 ${
                        isCurrent ? "opacity-100 font-medium" : isDone ? "opacity-60" : "opacity-30"
                      }`}
                    >
                      {isDone ? (
                        <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                      ) : isCurrent ? (
                        <RefreshCw className="w-4 h-4 text-blue-600 animate-spin shrink-0" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border border-slate-300 shrink-0"></div>
                      )}
                      <span className={isCurrent ? "text-blue-600" : isDone ? "text-slate-700" : "text-slate-400"}>
                        {step}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Column: Input and Upload Dropzone */}
            <div className="lg:col-span-7 space-y-6">
              
              {errorMessage && (
                <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex gap-2.5 items-start">
                  <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block mb-0.5">解析异常</span>
                    <span>{errorMessage}</span>
                  </div>
                </div>
              )}

              {/* Drag and Drop Zone */}
              <div 
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-200 hover:border-blue-500/50 hover:bg-blue-50/10 bg-white rounded-2xl p-8 text-center cursor-pointer transition-all group shadow-sm"
              >
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*"
                  className="hidden" 
                />
                
                <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-400 group-hover:text-blue-600 group-hover:border-blue-500/30 mx-auto mb-4 transition-colors shadow-inner">
                  <UploadCloud className="w-7 h-7" />
                </div>
                
                <h3 className="text-sm font-bold text-slate-700">
                  拖拽或选择医学报告照片导入
                </h3>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed max-w-sm mx-auto">
                  支持 JPG、PNG 图片格式。适合化验单、超声、出院小结、CT 胶片报告等。
                </p>
                
                <div className="mt-5 flex items-center justify-center gap-1.5 text-[10px] font-mono text-blue-600 bg-blue-50 border border-blue-200/60 px-3 py-1 rounded-full w-fit mx-auto">
                  <Lock className="w-3.5 h-3.5" />
                  本地 Tauri 图像加密通道
                </div>
              </div>

              {/* Divider */}
              <div className="flex items-center gap-3 text-slate-400 text-xs font-mono">
                <div className="h-px bg-slate-200 flex-1"></div>
                <span>或：粘贴报告文字进行智能合并</span>
                <div className="h-px bg-slate-200 flex-1"></div>
              </div>

              {/* Text Area Input */}
              <div className="space-y-2">
                <textarea
                  id="raw-text-input"
                  placeholder="可在此直接粘贴医院 APP (如微医、随申办、京医通等) 中的病历详情、化验数据文本..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  rows={6}
                  className="w-full bg-white border border-slate-200 rounded-xl p-4 text-xs font-mono text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 transition-all leading-relaxed custom-scrollbar shadow-inner"
                />
                <button
                  onClick={handleRawTextSubmit}
                  disabled={!inputText.trim()}
                  className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:cursor-not-allowed transition-all shadow-sm"
                >
                  <Zap className="w-3.5 h-3.5 stroke-[2.5]" />
                  OCR 文本智能解析
                </button>
              </div>

            </div>

            {/* Right Column: Click-to-Test Mock Presets (高保真中文病历一键模拟测试区) */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-sm">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    高保真病历模板一键演示
                  </h3>
                  <p className="text-slate-500 text-[11px] mt-1 leading-relaxed">
                    为了方便您在非生产环境下测试 <b>MedMe (医我)</b> 的 OCR 功能，我们准备了四类极具中国医院特色（协和、华西、瑞金等）的真实数据模型。点击即可一键模拟 OCR 提取：
                  </p>
                </div>

                <div className="space-y-2.5">
                  {mockTemplates.map((template) => {
                    const iconMap: { [key: string]: any } = {
                      Activity: Activity,
                      FileText: FileText,
                      Image: ImageIcon,
                      Pills: Pill
                    };
                    const Icon = iconMap[template.icon] || FileText;
                    
                    return (
                      <button
                        key={template.id}
                        id={`btn-${template.id}`}
                        onClick={() => handleTemplateClick(template)}
                        className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-blue-500/30 bg-slate-50/50 hover:bg-white text-left transition-all group cursor-pointer shadow-sm"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-400 group-hover:text-blue-600 transition-colors shadow-inner">
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <span className="text-xs font-semibold text-slate-700 block group-hover:text-slate-900 transition-colors truncate">
                              {template.name}
                            </span>
                            <span className="text-[10px] font-mono text-slate-400 block">
                              类别：{template.category === "lab" ? "指标化验单" : template.category === "outpatient" ? "门诊大病历" : template.category === "imaging" ? "超声/影像" : "临床药方"}
                            </span>
                          </div>
                        </div>
                        <div className="shrink-0 px-2.5 py-1 rounded bg-white group-hover:bg-blue-50/60 text-[10px] text-slate-500 group-hover:text-blue-600 border border-slate-200 group-hover:border-blue-200 font-semibold font-sans transition-all">
                          导入测试
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span className="text-[10px] text-slate-500 leading-relaxed">
                    <b>体验真实 OCR 识别</b>：在 AI Studio secrets 配置好后，你可以拖拽任何写有中文医学指标或诊断结果的图片、照片，大模型将自动、精确、无感地结构化它。
                  </span>
                </div>
              </div>
            </div>

          </div>
        )}
      </div>

    </div>
  );
}
