/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  ShieldCheck, 
  Lock,
  MessageSquare,
  HelpCircle,
  Clock,
  Heart
} from "lucide-react";
import { TimelineEvent, ChatMessage } from "../types";

interface VaultAssistantProps {
  timelineEvents: TimelineEvent[];
  hasApiKey: boolean;
}

export default function VaultAssistant({ timelineEvents, hasApiKey }: VaultAssistantProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Suggested Chinese medical queries based on Chinese patients needs
  const suggestions = [
    { text: "我四月份化验单上有什么指标异常吗？", q: "我四月份在协和医院做的血常规，化验单上有什么指标是异常的？说明了什么问题？" },
    { text: "得了急性胃炎之后，奥美拉唑和达喜该怎么吃？", q: "我最近在华西医院诊断了急性胃炎。奥美拉唑和达喜这两个药应该怎么配合服用？有什么饮食禁忌？" },
    { text: "报告里的轻度脂肪肝，该怎么逆转？", q: "我在瑞金医院超声查出有轻中度脂肪肝。请问这个脂肪肝能完全恢复吗？需要怎么做？" }
  ];

  // Initialize with a welcome message from the assistant
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: "welcome",
          role: "assistant",
          content: "您好！我是您的 **“医我” (MedMe) 专属健康助手**。\n\n我已安全绑定并加载了您的**本地病历生命时间线**。我能为您：\n1. **解读化验单指标**（对比协和、瑞金等多期化验报告）\n2. **指导用药配伍**（如奥美拉唑与达喜的吃法）\n3. **提供疾病生活常识**（如急性胃炎、轻度脂肪肝的康复逆转建议）\n\n您可以点击下方推荐的问题，或直接向我咨询！",
          timestamp: new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
        }
      ]);
    }
  }, []);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: "user",
      content: textToSend,
      timestamp: new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    if (!hasApiKey) {
      // Local simulation mode - generate extremely personalized and beautiful local mock replies
      setTimeout(() => {
        let simulationReply = "";
        
        const lowerText = textToSend.toLowerCase();
        if (lowerText.includes("四月") || lowerText.includes("血常规") || lowerText.includes("化验")) {
          simulationReply = `### 您的四月份血常规指标智析 🩸

根据您 2026-04-12 在 **北京协和医院** 的血常规报告，检测到以下异常：
1. **白细胞计数 (WBC) 偏高**（**11.4** 10^9/L，标准范围为 4.0 - 10.0）：白细胞是体内的免疫防线，当身体面临细菌性入侵时，它会紧急增加兵力。
2. **中性粒细胞百分比 (NEUT%) 偏高**（**78.5%**，标准范围为 50% - 70%）：中性粒细胞主要对抗细菌感染，它的增高进一步印证了可能存在轻度局部细菌发炎。

**💡 专属指导建议：**
- **可能原因**：白细胞增高多见于急性上呼吸道感染、急性胃肠炎、软组织发炎等。建议结合您当时是否有咳嗽、咽痛、或者拉肚子来综合判断。
- **作息调理**：切忌熬夜！熬夜会压制白细胞战斗力。多温水促排毒。
- **复查提醒**：如果不适症状已消失，建议在 1-2 周后就近门诊复查血常规，看白细胞是否已恢复正常。`;
        } else if (lowerText.includes("胃炎") || lowerText.includes("奥美拉唑") || lowerText.includes("达喜")) {
          simulationReply = `### 华西胃肠病用药与康复指南 💊

针对 2026-05-18 在 **四川大学华西医院** 诊断的**急性胃黏膜病变（急性胃炎）**，开具的奥美拉唑和铝碳酸镁片（达喜）配伍非常科学：

#### 1. 药物吃法协同方案：
*   **奥美拉唑钠肠溶片 (20mg)**：
    *   *用法*：**清晨起床空腹**，整片吞服，一日1次。
    *   *作用*：空腹吃可以使质子泵阻滞剂最大化接触胃壁细胞，发挥一整天抑酸、止痛、让胃粘膜休息的作用。
*   **达喜（铝碳酸镁片 - 1.0g）**：
    *   *用法*：**餐后 1 小时**或**睡前不适时**，嚼碎吞服，一日3次。
    *   *作用*：它能迅速在胃黏膜表面形成保护网，并中和多余胃酸。必须嚼碎，使其物理吸附面积最大化。

#### 2. 急性胃炎饮食“军规”：
- **黄金红线**：禁辛辣火锅、冰冷碳酸饮料、浓咖啡、浓茶。
- **养胃好物**：前 3 天主打小米粥、苏打饼干（弱碱性中和胃酸）、温软面条。
- **细嚼慢咽**：每口饭咀嚼 20 次以上，让唾液中的淀粉酶充分混合，减轻胃部机械性蠕动负担。`;
        } else if (lowerText.includes("脂肪肝") || lowerText.includes("逆转") || lowerText.includes("超声")) {
          simulationReply = `### 瑞金腹部超声：轻度脂肪肝逆转全攻略 🏃‍♂️

您 2026-06-05 在 **上海交通大学医学院附属瑞金医院** 体检结果提示 **轻-中度脂肪肝**。

请您放宽心，**脂肪肝是完全可以100%可逆、彻底恢复健康的！** 它就像肝脏里塞了几个临时小油包，只要通过科学管理，这些油就会被代谢掉：

#### 🏃‍♂️ 逆转脂肪肝的三个“核按钮”：
1.  **掐断“夜餐糖源”**：
    *   肝脏在夜间进行脂肪合成。**晚上 8 点后绝对禁食**。
    *   严格戒掉含糖饮料（可乐、奶茶、果汁）和精制甜点，这些是肝脏脂肪化的元凶。
2.  **每周 150 分钟“心率大作战”**：
    *   推荐：快走、慢跑、椭圆机、游泳。
    *   标准：每周 3-5 次，每次 30-50 分钟。运动时需保持心率在 **110 - 130 次/分钟**（身体微微出汗，能说话但不能唱歌的状态）。
3.  **地中海饮食原则**：
    *   用粗粮（糙米、燕麦、玉米）代替精米白面。
    *   每天保证一包无盐坚果，炒菜油换成橄榄油。

只要您坚持这套生活模式 **8-12 周**，三个月后复查 B 超，轻度脂肪肝大有概率能降级为“未见明显异常”！加油！`;
        } else {
          simulationReply = `### 医我 (MedMe) 专属智析回复 🔒

由于目前处于 **【演示沙盒模拟状态】**，如果您想要获得大模型对您自定义病历问题的完美深度解答，请按照以下步骤：
1. 点击 AI Studio 界面右上角的 **Settings** 菜单
2. 选择 **Secrets** 选项卡
3. 新增名为 \`GEMINI_API_KEY\` 的密钥，填入您的真实 Gemini API Key
4. 刷新网页

**当前保险箱内就诊记录摘要：**
*   **就诊事件数**：${timelineEvents.length} 份
*   **涵盖医院**：${Array.from(new Set(timelineEvents.map(e => e.hospital))).join("、") || "暂无记录"}

*提示：数据完全保留在 Tauri 本地强隔离沙盒中。*`;
        }

        const assistantMessage: ChatMessage = {
          id: `msg-${Date.now() + 1}`,
          role: "assistant",
          content: simulationReply,
          timestamp: new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
        };
        setMessages((prev) => [...prev, assistantMessage]);
        setIsLoading(false);
      }, 1500);
      return;
    }

    // Has API key - query our REAL server api /api/chat!
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMessage].map((m) => ({
            role: m.role,
            content: m.content
          })),
          timelineEvents: timelineEvents
        })
      });

      const result = await response.json();
      if (result.success && result.text) {
        const assistantMessage: ChatMessage = {
          id: `msg-${Date.now() + 1}`,
          role: "assistant",
          content: result.text,
          timestamp: new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
        };
        setMessages((prev) => [...prev, assistantMessage]);
      } else {
        throw new Error(result.error || "大模型交互异常");
      }
    } catch (err: any) {
      const errorMessage: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: "assistant",
        content: `⚠️ **就诊助手数据通道异常**\n\n通信失败。故障原因：${err.message || "未知连接错误"}\n\n请检查您的网络连接或确保在 AI Studio Secrets 中注入了有效的 \`GEMINI_API_KEY\`。`,
        timestamp: new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Simple, elegant Markdown renderer to display clean rich headings, bold texts, and lists
  const renderMarkdown = (text: string) => {
    const lines = text.split("\n");
    return lines.map((line, lineIdx) => {
      // 1. Headings (e.g., ### Title)
      if (line.startsWith("### ")) {
        return <h3 key={lineIdx} className="text-base font-bold text-blue-600 mt-4 mb-2 first:mt-0 font-sans tracking-tight">{line.substring(4)}</h3>;
      }
      if (line.startsWith("#### ")) {
        return <h4 key={lineIdx} className="text-sm font-bold text-slate-800 mt-3 mb-1.5 first:mt-0 font-sans">{line.substring(5)}</h4>;
      }
      if (line.startsWith("## ")) {
        return <h2 key={lineIdx} className="text-lg font-bold text-slate-800 mt-5 mb-3 first:mt-0 border-b border-slate-100 pb-1 font-sans">{line.substring(3)}</h2>;
      }
      if (line.startsWith("# ")) {
        return <h1 key={lineIdx} className="text-xl font-bold text-slate-900 mt-6 mb-4 first:mt-0 border-b-2 border-blue-500/20 pb-1.5 font-sans">{line.substring(2)}</h1>;
      }

      // 2. Bullet list items (e.g., - item or * item)
      if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
        const content = line.trim().substring(2);
        return (
          <li key={lineIdx} className="ml-4 list-disc text-xs md:text-sm text-slate-600 leading-relaxed mb-1">
            {parseInlineFormatting(content)}
          </li>
        );
      }

      // 3. Numbered list items (e.g., 1. item)
      const numMatch = line.trim().match(/^(\d+)\.\s(.*)/);
      if (numMatch) {
        return (
          <li key={lineIdx} className="ml-4 list-decimal text-xs md:text-sm text-slate-600 leading-relaxed mb-1.5">
            {parseInlineFormatting(numMatch[2])}
          </li>
        );
      }

      // 4. Standard lines
      if (line.trim() === "") {
        return <div key={lineIdx} className="h-2.5"></div>;
      }

      return (
        <p key={lineIdx} className="text-xs md:text-sm text-slate-600 leading-relaxed mb-2 font-mono">
          {parseInlineFormatting(line)}
        </p>
      );
    });
  };

  // Helper to parse **bold** style inside markdown lines
  const parseInlineFormatting = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, idx) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return <strong key={idx} className="font-bold text-slate-900 mx-0.5">{part.substring(2, part.length - 2)}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="flex-1 flex flex-col h-screen overflow-hidden bg-slate-50 text-slate-800 font-sans">
      
      {/* Header */}
      <div className="border-b border-slate-200 bg-white p-6 flex items-center justify-between shadow-sm">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Bot className="w-6 h-6 text-blue-600" />
            医我 AI 全景智析
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-500 font-normal">
              Vault Assistant
            </span>
          </h1>
          <p className="text-slate-500 text-xs mt-1">
            专为患者服务的智能顾问，融合您已导入的全部生命时间线档案，提供精细化的健康趋势对比和指标问答。
          </p>
        </div>

        {/* Security Indicator */}
        <div className="flex items-center gap-1.5 text-xs text-blue-600 bg-blue-50 border border-blue-200/60 px-3 py-1.5 rounded-xl font-medium">
          <Lock className="w-3.5 h-3.5 stroke-[2.5]" />
          内存级沙盒隔离
        </div>
      </div>

      {/* Suggestion list */}
      {messages.length <= 1 && (
        <div className="p-6 pb-2 shrink-0 max-w-4xl mx-auto w-full">
          <div className="flex items-center gap-1.5 text-slate-500 text-xs mb-3 font-medium">
            <HelpCircle className="w-4 h-4 text-blue-600" />
            快捷就诊追问 (结合您的时间线记录)：
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {suggestions.map((s, idx) => (
              <button
                key={idx}
                id={`suggestion-btn-${idx}`}
                onClick={() => handleSendMessage(s.q)}
                disabled={timelineEvents.length === 0}
                className="p-3.5 rounded-xl border border-slate-200 hover:border-blue-500/30 bg-white hover:bg-slate-50/50 text-left transition-all group disabled:opacity-40 disabled:hover:border-slate-200 disabled:cursor-not-allowed cursor-pointer shadow-sm"
              >
                <span className="text-xs font-medium text-slate-700 group-hover:text-blue-600 block mb-1">
                  {s.text}
                </span>
                <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  基于本地医疗档案
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Conversation Thread */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar max-w-4xl mx-auto w-full">
        {messages.map((m) => {
          const isUser = m.role === "user";
          return (
            <div 
              key={m.id} 
              className={`flex gap-4 ${isUser ? "flex-row-reverse" : "flex-row"}`}
            >
              {/* Avatar Icon */}
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border shadow-sm ${
                isUser 
                  ? "bg-slate-100 border-slate-200 text-slate-600" 
                  : "bg-blue-600 border-blue-600 text-white"
              }`}>
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4.5 h-4.5 stroke-[2.5]" />}
              </div>

              {/* Message Bubble */}
              <div className="space-y-1 max-w-[80%]">
                <div className={`p-4 rounded-2xl border text-sm shadow-sm ${
                  isUser 
                    ? "bg-white border-slate-200 text-slate-800 rounded-tr-none" 
                    : "bg-white border-slate-200 text-slate-800 rounded-tl-none"
                }`}>
                  {isUser ? (
                    <p className="font-mono whitespace-pre-wrap text-xs md:text-sm leading-relaxed">{m.content}</p>
                  ) : (
                    <div className="space-y-2">
                      {renderMarkdown(m.content)}
                    </div>
                  )}
                </div>
                
                {/* Timestamp & privacy sign */}
                <div className={`flex items-center gap-2 text-[10px] text-slate-400 font-mono ${isUser ? "justify-end" : "justify-start"}`}>
                  <span>{m.timestamp}</span>
                  {!isUser && (
                    <span className="flex items-center gap-0.5 text-blue-600 font-semibold uppercase">
                      <ShieldCheck className="w-3 h-3" />
                      SECURE VAULT OK
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* Loading Bubble */}
        {isLoading && (
          <div className="flex gap-4">
            <div className="w-9 h-9 rounded-xl bg-blue-600 border-blue-600 text-white flex items-center justify-center shrink-0 border shadow-sm animate-pulse">
              <Bot className="w-4.5 h-4.5 stroke-[2.5]" />
            </div>
            <div className="space-y-1.5 max-w-[80%]">
              <div className="p-4 rounded-2xl border border-slate-200 bg-white text-slate-600 rounded-tl-none flex items-center gap-2 shadow-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce [animation-delay:0.4s]"></span>
                <span className="text-xs text-slate-500 font-mono ml-1.5">医我脑力整合计算中...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Chat input controls */}
      <div className="p-6 border-t border-slate-200 bg-white shrink-0 shadow-sm">
        <div className="max-w-4xl mx-auto w-full">
          <div className="flex gap-3 bg-slate-50 border border-slate-200 rounded-2xl p-2 focus-within:border-blue-500/50 focus-within:bg-white transition-all items-center shadow-inner">
            <input
              type="text"
              id="assistant-chat-input"
              placeholder={timelineEvents.length === 0 ? "请先前往【纸质病历 OCR】导入病历，才能启用对话哦..." : "向您的个人病历助手提问，例如：'对比我4月和6月的复查指标，有什么变化？'"}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              disabled={timelineEvents.length === 0 || isLoading}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleSendMessage(inputValue);
              }}
              className="flex-1 bg-transparent py-2.5 px-3 border-none focus:outline-none focus:ring-0 text-sm text-slate-800 placeholder-slate-400 disabled:opacity-40 disabled:cursor-not-allowed font-sans"
            />
            <button
              onClick={() => handleSendMessage(inputValue)}
              disabled={!inputValue.trim() || isLoading || timelineEvents.length === 0}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white w-10 h-10 rounded-xl flex items-center justify-center cursor-pointer disabled:cursor-not-allowed shrink-0 transition-colors shadow-sm"
            >
              <Send className="w-4.5 h-4.5" />
            </button>
          </div>
          
          <div className="text-[10px] text-slate-400 mt-2.5 text-center flex items-center justify-center gap-1 font-mono">
            <ShieldCheck className="w-3.5 h-3.5" />
            离线化沙箱大模型问答：此对话数据完全处于本地 Tauri 隔离沙盒物理加密保护中，保护个人医疗主权。
          </div>
        </div>
      </div>

    </div>
  );
}
