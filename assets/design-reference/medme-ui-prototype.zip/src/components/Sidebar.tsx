/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  ShieldCheck, 
  Activity, 
  UploadCloud, 
  MessageSquare, 
  Lock, 
  Database,
  Cpu,
  Info
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  hasApiKey: boolean;
  eventCount: number;
}

export default function Sidebar({ activeTab, setActiveTab, hasApiKey, eventCount }: SidebarProps) {
  const menuItems = [
    {
      id: "timeline",
      label: "生命时间线",
      subLabel: "Medical Lifeline",
      icon: Activity,
      badge: eventCount > 0 ? eventCount : undefined
    },
    {
      id: "ingest",
      label: "纸质病历 OCR",
      subLabel: "Data Ingestion",
      icon: UploadCloud,
    },
    {
      id: "assistant",
      label: "医我智析",
      subLabel: "Vault Assistant",
      icon: MessageSquare,
    }
  ];

  return (
    <div className="w-72 bg-white border-r border-slate-200 flex flex-col h-screen text-slate-600 font-sans shrink-0 select-none">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 shadow-sm border border-blue-100">
            <ShieldCheck className="w-6 h-6 stroke-[2]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-sans font-bold text-xl text-blue-600 tracking-tight">MedMe</span>
              <span className="font-sans font-bold text-xl text-slate-950">医我</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400 tracking-widest uppercase block mt-0.5">
              Personal Health Vault
            </span>
          </div>
        </div>

        {/* Security / Isolation Shield Badge */}
        <div className="mt-5 p-3 rounded-xl bg-emerald-50/60 border border-emerald-100 flex items-center gap-2">
          <Lock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <div className="min-w-0">
            <span className="text-[11px] font-semibold text-emerald-800 block">Tauri 沙盒内存隔离已激活</span>
            <span className="text-[9px] font-mono text-emerald-600 block truncate">AES-256 本地密钥存储保护</span>
          </div>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 p-4 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`sidebar-tab-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between p-3.5 rounded-xl transition-all duration-200 cursor-pointer text-left group ${
                isActive
                  ? "bg-blue-50 text-blue-700 font-medium border border-blue-100/40"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-5 h-5 transition-transform group-hover:scale-105 ${isActive ? "text-blue-600" : "text-slate-400"}`} />
                <div>
                  <span className={`text-sm font-medium block ${isActive ? "text-blue-900" : "text-slate-700"}`}>
                    {item.label}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 block">
                    {item.subLabel}
                  </span>
                </div>
              </div>
              {item.badge !== undefined && (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${isActive ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Security Status Panel */}
      <div className="p-4 border-t border-slate-200 bg-slate-50/50 text-[11px] text-slate-500 space-y-3">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 font-mono">
            <Database className="w-3.5 h-3.5 text-slate-400" />
            数据孤岛打破状态
          </span>
          <span className="font-mono text-emerald-600 font-bold">100% 本地化</span>
        </div>

        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 font-mono">
            <Cpu className="w-3.5 h-3.5 text-slate-400" />
            静默处理引擎
          </span>
          <span className="font-mono text-blue-600 font-bold">
            {hasApiKey ? "Gemini 双工" : "本地模拟"}
          </span>
        </div>

        {!hasApiKey && (
          <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200/60 text-amber-800 flex gap-2">
            <Info className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
            <span className="text-[10px] leading-relaxed">
              检测到未配置 <b>GEMINI_API_KEY</b>，App 将采用本地快速仿真进行演示。配置后可获得完全真实的病历大模型 OCR 与智析体验。
            </span>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-slate-200 flex items-center justify-between text-[10px] font-mono text-slate-400">
        <span>© MedMe Team 2026</span>
        <span>v1.2.0 (Stable)</span>
      </div>
    </div>
  );
}
