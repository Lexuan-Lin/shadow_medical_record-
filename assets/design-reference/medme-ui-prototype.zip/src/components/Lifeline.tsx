/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Search, 
  Calendar, 
  MapPin, 
  Briefcase, 
  ChevronDown, 
  ChevronUp, 
  AlertTriangle, 
  ArrowUpRight, 
  ArrowDownRight,
  ShieldCheck, 
  Trash2,
  Filter,
  FileText,
  Activity,
  Image as ImageIcon,
  Pill,
  Heart,
  Layers
} from "lucide-react";
import { TimelineEvent, TimelineCategory, LabIndicator } from "../types";

interface LifelineProps {
  events: TimelineEvent[];
  onDeleteEvent: (id: string) => void;
}

export default function Lifeline({ events, onDeleteEvent }: LifelineProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [expandedEventId, setExpandedEventId] = useState<string | null>(null);
  const [expandedSubEventId, setExpandedSubEventId] = useState<string | null>(null);
  const [isAggregationEnabled, setIsAggregationEnabled] = useState<boolean>(true);

  // Filter events based on search term and category filter
  const filteredEvents = events.filter((event) => {
    const matchesSearch = 
      event.hospital.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.summary.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = 
      selectedCategory === "all" || event.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  // Sort events by date descending
  const sortedEvents = [...filteredEvents].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  // Clustering/Aggregation Logic:
  // We group adjacent events in time into an "Episode" parent container if:
  // 1. The interval gap between consecutive sorted events is <= 10 days
  // 2. The cluster contains at least 3 events
  // If a cluster has fewer than 3 events, we expand and display them as standard standalone cards.
  const timelineGroups: {
    id: string;
    isCluster: boolean;
    startDate: string;
    endDate: string;
    events: TimelineEvent[];
    title: string;
    summary: string;
    hospital: string;
  }[] = [];

  if (isAggregationEnabled && sortedEvents.length > 0) {
    const clusters: TimelineEvent[][] = [];
    let currentCluster: TimelineEvent[] = [sortedEvents[0]];

    for (let i = 1; i < sortedEvents.length; i++) {
      const prev = sortedEvents[i - 1];
      const curr = sortedEvents[i];
      const prevTime = new Date(prev.date).getTime();
      const currTime = new Date(curr.date).getTime();
      const diffDays = Math.abs(prevTime - currTime) / (1000 * 60 * 60 * 24);

      if (diffDays <= 10) {
        currentCluster.push(curr);
      } else {
        clusters.push(currentCluster);
        currentCluster = [curr];
      }
    }
    clusters.push(currentCluster);

    clusters.forEach((cluster, idx) => {
      if (cluster.length >= 3) {
        const dates = cluster.map(e => new Date(e.date).getTime());
        const minDate = new Date(Math.min(...dates)).toISOString().split("T")[0];
        const maxDate = new Date(Math.max(...dates)).toISOString().split("T")[0];

        const hospitals = Array.from(new Set(cluster.map(e => e.hospital)));
        const primaryHospital = hospitals[0] || "综合医院";
        const hospitalText =
          hospitals.length > 1
            ? `${primaryHospital} 等 ${hospitals.length} 家医院`
            : primaryHospital;

        const categories = Array.from(new Set(cluster.map(e => e.category)));
        const categoryLabels = categories
          .map(c => {
            if (c === "outpatient") return "病历";
            if (c === "lab") return "化验";
            if (c === "imaging") return "检查";
            if (c === "prescription") return "处方";
            return "就诊";
          })
          .join("/");

        const depts = Array.from(new Set(cluster.map(e => e.department)));
        const deptText = depts.join("、");

        const title = `高频密集诊疗期聚合 (${deptText} • ${categoryLabels})`;
        const summary = `在此期间共高频产生 ${cluster.length} 份诊疗档案（涉及：${cluster.map(e => e.title).join("、")}），常对应住院、手术、多科室会诊或短期高密复查事件。`;

        timelineGroups.push({
          id: `cluster-${idx}-${minDate}`,
          isCluster: true,
          startDate: minDate,
          endDate: maxDate,
          events: cluster,
          title,
          summary,
          hospital: hospitalText
        });
      } else {
        cluster.forEach(event => {
          timelineGroups.push({
            id: event.id,
            isCluster: false,
            startDate: event.date,
            endDate: event.date,
            events: [event],
            title: event.title,
            summary: event.summary,
            hospital: event.hospital
          });
        });
      }
    });
  } else {
    // Aggregation is disabled or no events to process
    sortedEvents.forEach(event => {
      timelineGroups.push({
        id: event.id,
        isCluster: false,
        startDate: event.date,
        endDate: event.date,
        events: [event],
        title: event.title,
        summary: event.summary,
        hospital: event.hospital
      });
    });
  }

  // Helper stats
  const totalHospitals = new Set(events.map(e => e.hospital)).size;
  const abnormalCount = events.reduce((acc, event) => {
    if (event.labIndicators) {
      const abnormalInEvent = event.labIndicators.filter(i => i.status !== "normal").length;
      return acc + abnormalInEvent;
    }
    return acc;
  }, 0);

  const getCategoryMeta = (cat: TimelineCategory) => {
    switch (cat) {
      case TimelineCategory.OUTPATIENT:
        return {
          label: "门诊病历",
          icon: FileText,
          bg: "bg-blue-50 text-blue-700 border-blue-200/60",
          accentColor: "border-blue-400"
        };
      case TimelineCategory.LAB:
        return {
          label: "指标化验",
          icon: Activity,
          bg: "bg-emerald-50 text-emerald-700 border-emerald-200/60",
          accentColor: "border-emerald-400"
        };
      case TimelineCategory.IMAGING:
        return {
          label: "检查影像",
          icon: ImageIcon,
          bg: "bg-purple-50 text-purple-700 border-purple-200/60",
          accentColor: "border-purple-400"
        };
      case TimelineCategory.PRESCRIPTION:
        return {
          label: "药方处方",
          icon: Pill,
          bg: "bg-amber-50 text-amber-700 border-amber-200/60",
          accentColor: "border-amber-400"
        };
    }
  };

  const toggleExpand = (id: string) => {
    setExpandedEventId(expandedEventId === id ? null : id);
  };

  // Helper to render clearer names/titles with dynamic visual status indicators
  const renderClearTitleAndBadge = (event: TimelineEvent) => {
    let badgeText = "";
    let badgeColor = "bg-slate-100 text-slate-600 border-slate-200";
    
    if (event.category === TimelineCategory.LAB && event.labIndicators) {
      const abnormalList = event.labIndicators.filter(i => i.status !== "normal");
      if (abnormalList.length > 0) {
        badgeText = `${abnormalList.length} 项指标异常`;
        badgeColor = "bg-rose-50 border-rose-100 text-rose-700 font-bold";
      } else {
        badgeText = "全部指标正常";
        badgeColor = "bg-emerald-50 border-emerald-100 text-emerald-700 font-semibold";
      }
    } else if (event.category === TimelineCategory.PRESCRIPTION && event.prescriptions) {
      badgeText = `${event.prescriptions.length} 种联用药物`;
      badgeColor = "bg-blue-50 border-blue-100 text-blue-700 font-semibold";
    } else if (event.category === TimelineCategory.IMAGING && event.imagingResult) {
      badgeText = "临床影像学报告";
      badgeColor = "bg-purple-50 border-purple-100 text-purple-700 font-semibold";
    } else if (event.category === TimelineCategory.OUTPATIENT) {
      badgeText = "纸质门诊病历";
      badgeColor = "bg-indigo-50 border-indigo-100 text-indigo-700 font-semibold";
    }

    return (
      <div className="flex flex-col gap-1.5 sm:flex-row sm:items-center sm:gap-3 flex-wrap">
        <span className="text-base md:text-lg font-bold text-slate-900 tracking-tight">
          {event.title}
        </span>
        {badgeText && (
          <span className={`px-2.5 py-0.5 text-[10px] rounded-lg border w-fit shadow-sm uppercase tracking-wide ${badgeColor}`}>
            {badgeText}
          </span>
        )}
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col h-screen overflow-hidden bg-slate-50 text-slate-800 font-sans">
      
      {/* Header Banner */}
      <div className="border-b border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Heart className="w-6 h-6 text-blue-600 fill-blue-500/10" />
              就诊生命时间线
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-500 font-normal">
                Lifeline
              </span>
            </h1>
            <p className="text-slate-500 text-xs mt-1">
              自动聚合和打通您的医院就诊断代、多渠道纸质化验单，突破碎片数据孤岛，实现个人专属全景病历。
            </p>
          </div>
          
          {/* Quick Metrics */}
          <div className="flex gap-4">
            <div className="bg-white border border-slate-200 shadow-sm px-4 py-2.5 rounded-xl text-center min-w-[85px]">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">聚合医院</span>
              <span className="text-xl font-bold font-mono text-slate-900">{totalHospitals} <span className="text-xs font-normal text-slate-500">家</span></span>
            </div>
            <div className="bg-white border border-slate-200 shadow-sm px-4 py-2.5 rounded-xl text-center min-w-[85px]">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">归档档案</span>
              <span className="text-xl font-bold font-mono text-slate-900">{events.length} <span className="text-xs font-normal text-slate-500">份</span></span>
            </div>
            <div className="bg-white border border-slate-200 shadow-sm px-4 py-2.5 rounded-xl text-center min-w-[85px]">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">关注异常</span>
              <span className={`text-xl font-bold font-mono ${abnormalCount > 0 ? "text-amber-600" : "text-emerald-600"}`}>
                {abnormalCount} <span className="text-xs font-normal text-slate-500">项</span>
              </span>
            </div>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
              <input
                type="text"
                id="lifeline-search"
                placeholder="搜索疾病诊断、医院、就诊科室或检查指标项..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 transition-all"
              />
            </div>

            <div className="flex gap-2 shrink-0 overflow-x-auto pb-1 md:pb-0">
              {[
                { id: "all", label: "全部记录" },
                { id: "outpatient", label: "门诊病历" },
                { id: "lab", label: "指标化验" },
                { id: "imaging", label: "检查影像" },
                { id: "prescription", label: "药方处方" }
              ].map((category) => (
                <button
                  key={category.id}
                  id={`filter-btn-${category.id}`}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-medium cursor-pointer border transition-all duration-200 whitespace-nowrap ${
                    selectedCategory === category.id
                      ? "bg-blue-600 border-blue-600 text-white font-semibold shadow-sm"
                      : "bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300 hover:bg-slate-50/50"
                  }`}
                >
                  {category.label}
                </button>
              ))}
            </div>
          </div>

          {/* Aggregation Smart Toggle Switch */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-150 flex-wrap gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200/50 flex items-center justify-center text-blue-600 shrink-0">
                <Layers className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-slate-700 block">
                  高频密集诊疗期智能打包聚合
                </span>
                <span className="text-[10px] text-slate-500 leading-relaxed block truncate max-w-xl">
                  当同一患者在 10 天内产生 3 份以上检查报告时（如住院、手术或密集复诊），自动折叠为同一父集，精简长河视图。
                </span>
              </div>
            </div>
            
            <div className="flex items-center gap-3 shrink-0">
              <span className="text-xs font-semibold text-slate-500 font-mono">
                {isAggregationEnabled ? "聚合已启用" : "已展示原始长河"}
              </span>
              <button
                onClick={() => setIsAggregationEnabled(!isAggregationEnabled)}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  isAggregationEnabled ? "bg-blue-600" : "bg-slate-200"
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    isAggregationEnabled ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Timeline View Area */}
      <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6 custom-scrollbar">
        {timelineGroups.length === 0 ? (
          <div className="h-96 flex flex-col items-center justify-center text-center max-w-md mx-auto">
            <div className="w-16 h-16 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-400 mb-4 shadow-sm">
              <Filter className="w-8 h-8 stroke-[1.5]" />
            </div>
            <h3 className="text-lg font-bold text-slate-800">未检索到病历记录</h3>
            <p className="text-slate-500 text-xs mt-2 leading-relaxed">
              {events.length === 0 
                ? "您的个人健康保险箱内暂无数据。请前往左侧【纸质病历 OCR】模块，上传就诊报告、血常规单或药方处方，体验极速静默 AI 解析导入！" 
                : "请尝试更换筛选条件，或重置搜索词再次查找。"}
            </p>
          </div>
        ) : (
          <div className="relative max-w-4xl mx-auto">
            
            {/* The Vertical Axis line */}
            <div className="absolute left-6 md:left-8 top-4 bottom-4 w-0.5 bg-slate-200 z-0"></div>

            {/* Timeline Cards */}
            <div className="space-y-8 relative z-10">
              {timelineGroups.map((group) => {
                const isExpanded = expandedEventId === group.id;

                // Case A: Group is an Aggregated Cluster Group
                if (group.isCluster) {
                  return (
                    <div key={group.id} className="flex gap-4 md:gap-6 items-start group">
                      
                      {/* Circle timeline anchor for Cluster */}
                      <button
                        onClick={() => toggleExpand(group.id)}
                        className={`w-12 h-12 md:w-16 md:h-16 rounded-2xl flex items-center justify-center border-2 shrink-0 transition-all duration-300 shadow-sm ${
                          isExpanded
                            ? "bg-blue-50 border-blue-500 text-blue-600 scale-105"
                            : "bg-white border-slate-200 text-slate-400 group-hover:border-slate-300 hover:scale-105"
                        }`}
                      >
                        <Layers className="w-5 h-5 md:w-6 md:h-6" />
                      </button>

                      {/* Timeline Card Container */}
                      <div className="flex-1 bg-white border border-slate-200 hover:border-slate-300 rounded-2xl transition-all duration-200 overflow-hidden shadow-sm hover:shadow-md">
                        
                        {/* Summary Header */}
                        <div 
                          onClick={() => toggleExpand(group.id)}
                          className="p-5 md:p-6 cursor-pointer flex justify-between items-start gap-4 select-none bg-gradient-to-r from-blue-50/20 to-transparent"
                        >
                          <div className="space-y-1.5 flex-1 min-w-0">
                            {/* Top row: category and date */}
                            <div className="flex flex-wrap items-center gap-2.5 text-xs">
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider font-sans border uppercase bg-blue-50 text-blue-700 border-blue-200/60">
                                密集治疗期聚合 ({group.events.length} 份报告)
                              </span>
                              <span className="text-slate-500 flex items-center gap-1 font-mono font-medium">
                                <Calendar className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                                {group.startDate} 至 {group.endDate}
                              </span>
                              <span className="text-slate-500 flex items-center gap-1 font-sans font-medium truncate max-w-[200px]">
                                <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                                {group.hospital}
                              </span>
                            </div>

                            {/* Title */}
                            <h3 className="text-base md:text-lg font-extrabold text-blue-900 tracking-tight truncate">
                              {group.title}
                            </h3>

                            {/* Subtitle / Description */}
                            <p className="text-xs text-slate-500 leading-relaxed font-sans max-w-2xl mt-1">
                              <span className="font-semibold text-blue-700">合并摘要：</span>
                              {group.summary}
                            </p>
                          </div>

                          {/* Right Chevron & Status */}
                          <div className="flex flex-col items-end gap-3 self-stretch justify-between shrink-0">
                            <span className="flex items-center gap-1 text-[10px] text-blue-700 bg-blue-50 border border-blue-200/60 px-2 py-0.5 rounded-lg font-semibold">
                              已端加密
                            </span>
                            {isExpanded ? (
                              <ChevronUp className="w-5 h-5 text-blue-600 transition-colors" />
                            ) : (
                              <ChevronDown className="w-5 h-5 text-slate-400 group-hover:text-slate-600 transition-colors" />
                            )}
                          </div>
                        </div>

                        {/* Expanded Sub-Timeline List */}
                        {isExpanded && (
                          <div className="border-t border-slate-100 bg-slate-50/50 p-5 md:p-6 space-y-5">
                            <div className="text-xs font-bold text-slate-500 flex items-center gap-1.5 mb-1">
                              <Layers className="w-4 h-4 text-blue-600 shrink-0" />
                              <span>以下为该阶段内被收纳的极密检查项目：</span>
                            </div>
                            
                            {/* Inner Sub-timeline Thread */}
                            <div className="relative pl-6 border-l border-slate-200 space-y-6">
                              {group.events.map((subEvent, subIdx) => {
                                const subMeta = getCategoryMeta(subEvent.category);
                                const isSubExpanded = expandedSubEventId === subEvent.id;

                                return (
                                  <div key={subEvent.id} className="relative group/sub">
                                    
                                    {/* Left Sub Anchor Dot */}
                                    <div className={`absolute -left-[31px] top-2 w-4 h-4 rounded-full border-2 bg-white flex items-center justify-center transition-all ${
                                      isSubExpanded ? "border-blue-600" : "border-slate-300 group-hover/sub:border-slate-400"
                                    }`}>
                                      <div className={`w-1.5 h-1.5 rounded-full ${isSubExpanded ? "bg-blue-600" : "bg-slate-400"}`}></div>
                                    </div>

                                    {/* Sub-Event Inner Card Container */}
                                    <div className="bg-white border border-slate-150 rounded-xl overflow-hidden hover:border-slate-250 hover:shadow-sm transition-all">
                                      
                                      {/* Sub card Header */}
                                      <div 
                                        onClick={() => setExpandedSubEventId(isSubExpanded ? null : subEvent.id)}
                                        className="p-4 cursor-pointer flex justify-between items-center gap-4 bg-slate-50/20 hover:bg-slate-50 transition-colors select-none"
                                      >
                                        <div className="flex-1 min-w-0">
                                          <div className="flex flex-wrap items-center gap-2 text-[10px] text-slate-400 mb-1 font-mono">
                                            <span className={`px-2 py-0.5 rounded text-[9px] font-bold border uppercase shrink-0 ${subMeta.bg}`}>
                                              {subMeta.label}
                                            </span>
                                            <span>{subEvent.date}</span>
                                            <span>•</span>
                                            <span className="truncate max-w-[120px]">{subEvent.hospital}</span>
                                            <span>•</span>
                                            <span className="font-sans font-medium text-slate-500">{subEvent.department}</span>
                                          </div>
                                          
                                          {/* Dynamically formatted clearer title & abnormal indicator tag */}
                                          <div className="flex items-center gap-2">
                                            <h4 className="text-sm font-bold text-slate-800 truncate">
                                              {subEvent.title}
                                            </h4>
                                            {subEvent.category === TimelineCategory.LAB && subEvent.labIndicators && (
                                              <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-rose-50 border border-rose-200 text-rose-700 font-sans">
                                                {subEvent.labIndicators.filter(i => i.status !== "normal").length}项异常
                                              </span>
                                            )}
                                          </div>

                                          {/* Clear high-contrast diagnosis badge line */}
                                          <div className="flex items-center gap-1.5 mt-1">
                                            <span className="text-[10px] font-bold text-slate-700 shrink-0 bg-slate-100 border border-slate-200 px-1 py-0.2 rounded">诊断：</span>
                                            <span className="text-[11px] text-slate-700 truncate select-all">{subEvent.summary}</span>
                                          </div>
                                        </div>

                                        <div className="flex items-center gap-2 shrink-0">
                                          <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
                                            {isSubExpanded ? "点击折叠" : "查看详情"}
                                          </span>
                                          {isSubExpanded ? (
                                            <ChevronUp className="w-4 h-4 text-slate-400" />
                                          ) : (
                                            <ChevronDown className="w-4 h-4 text-slate-400" />
                                          )}
                                        </div>
                                      </div>

                                      {/* Sub-Event Inner Expanded Details */}
                                      {isSubExpanded && (
                                        <div className="p-4 border-t border-slate-100 bg-slate-50/10 space-y-4">
                                          
                                          {/* Lab Indicator grid */}
                                          {subEvent.category === TimelineCategory.LAB && subEvent.labIndicators && (
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                                              {subEvent.labIndicators.map((indicator, idx) => {
                                                const isHigh = indicator.status === "high";
                                                const isLow = indicator.status === "low";
                                                
                                                return (
                                                  <div 
                                                    key={idx} 
                                                    className={`p-2.5 rounded-lg border flex justify-between items-center text-xs ${
                                                      isHigh 
                                                        ? "bg-amber-50/60 border-amber-200" 
                                                        : isLow 
                                                          ? "bg-blue-50/60 border-blue-200" 
                                                          : "bg-white border-slate-200/80 shadow-sm"
                                                    }`}
                                                  >
                                                    <div>
                                                      <div className="flex items-center gap-1.5">
                                                        <span className="font-bold text-slate-700">{indicator.name}</span>
                                                        {indicator.abbr && (
                                                          <span className="text-[9px] font-mono text-slate-400 bg-slate-150 px-1 py-0.5 rounded">
                                                            {indicator.abbr}
                                                          </span>
                                                        )}
                                                      </div>
                                                      <span className="text-[10px] font-mono text-slate-400 block mt-0.5">
                                                        参考: {indicator.referenceRange} {indicator.unit}
                                                      </span>
                                                    </div>
                                                    <div className="text-right flex items-center gap-2">
                                                      <span className={`font-mono font-bold ${
                                                        isHigh ? "text-amber-600" : isLow ? "text-blue-600" : "text-emerald-600"
                                                      }`}>
                                                        {indicator.value}
                                                      </span>
                                                      <span className="text-[10px] text-slate-400 font-sans">{indicator.unit}</span>
                                                      {isHigh && <ArrowUpRight className="w-3.5 h-3.5 text-amber-600 stroke-[2.5]" />}
                                                      {isLow && <ArrowDownRight className="w-3.5 h-3.5 text-blue-600 stroke-[2.5]" />}
                                                    </div>
                                                  </div>
                                                );
                                              })}
                                            </div>
                                          )}

                                          {/* Outpatient case rawText */}
                                          {subEvent.category === TimelineCategory.OUTPATIENT && (
                                            <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 font-mono text-xs text-slate-700 whitespace-pre-wrap leading-relaxed shadow-inner select-text">
                                              {subEvent.rawText}
                                            </div>
                                          )}

                                          {/* Ultrasound/CT imaging findings and conclusions */}
                                          {subEvent.category === TimelineCategory.IMAGING && subEvent.imagingResult && (
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                              <div className="bg-white border border-slate-200 p-3 rounded-lg text-xs space-y-1 shadow-sm select-text">
                                                <span className="font-semibold text-slate-500 block">影像所见 (Findings)</span>
                                                <p className="text-slate-700 font-mono leading-relaxed">{subEvent.imagingResult.finding}</p>
                                              </div>
                                              <div className="bg-amber-50/40 border border-amber-200 p-3 rounded-lg text-xs space-y-1 shadow-sm select-text">
                                                <span className="font-semibold text-amber-800 block">诊断结论 (Conclusions)</span>
                                                <p className="text-amber-950 font-bold font-mono leading-relaxed">{subEvent.imagingResult.conclusion}</p>
                                              </div>
                                            </div>
                                          )}

                                          {/* Prescription medicine lists */}
                                          {subEvent.category === TimelineCategory.PRESCRIPTION && subEvent.prescriptions && (
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                                              {subEvent.prescriptions.map((med, idx) => (
                                                <div key={idx} className="bg-white border border-slate-200 p-3 rounded-lg flex justify-between items-center text-xs shadow-sm">
                                                  <div>
                                                    <span className="font-bold text-slate-700 block">{med.drugName}</span>
                                                    <span className="text-[10px] font-mono text-slate-400 mt-0.5 block">用法：{med.dosage}</span>
                                                  </div>
                                                  <div className="text-right shrink-0">
                                                    <span className="text-[10px] text-slate-400 block">规格: {med.specification}</span>
                                                    <span className="text-[10px] font-bold font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded inline-block mt-0.5">
                                                      数量: {med.quantity}
                                                    </span>
                                                  </div>
                                                </div>
                                              ))}
                                            </div>
                                          )}

                                          {/* AI Expert Interpretation panel */}
                                          {subEvent.aiInterpretation && (
                                            <div className="bg-emerald-50/50 border border-emerald-200 rounded-lg p-4 text-xs space-y-1.5 shadow-sm">
                                              <div className="flex items-center gap-1.5">
                                                <Heart className="w-3.5 h-3.5 text-emerald-600 fill-current" />
                                                <span className="font-bold text-emerald-800">医我智析报告解读</span>
                                              </div>
                                              <p className="text-slate-700 leading-relaxed whitespace-pre-wrap select-text">{subEvent.aiInterpretation}</p>
                                            </div>
                                          )}

                                          {/* Action footer within inner sub card */}
                                          <div className="flex justify-between items-center pt-2.5 border-t border-slate-100 text-[10px] text-slate-400">
                                            <span>
                                              加密密匙：AES-256 本地锁死保护中
                                            </span>
                                            <button
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                if (confirm("确定要永久删除该记录吗？删除后将无法恢复。")) {
                                                  onDeleteEvent(subEvent.id);
                                                }
                                              }}
                                              className="text-red-500 hover:text-red-700 flex items-center gap-1 cursor-pointer hover:underline"
                                            >
                                              <Trash2 className="w-3 h-3" />
                                              彻底抹除单份
                                            </button>
                                          </div>

                                        </div>
                                      )}

                                    </div>
                                  </div>
                                );
                              })}
                            </div>

                          </div>
                        )}

                      </div>
                    </div>
                  );
                }

                // Case B: Group is an Individual Normal Event Card
                const event = group.events[0];
                const meta = getCategoryMeta(event.category);
                const Icon = meta.icon;

                return (
                  <div key={event.id} className="flex gap-4 md:gap-6 items-start group">
                    
                    {/* Circle timeline anchor */}
                    <button
                      onClick={() => toggleExpand(event.id)}
                      className={`w-12 h-12 md:w-16 md:h-16 rounded-2xl flex items-center justify-center border-2 shrink-0 transition-all duration-300 shadow-sm ${
                        isExpanded
                          ? "bg-white border-blue-600 text-blue-600 scale-105"
                          : "bg-white border-slate-200 text-slate-400 group-hover:border-slate-300 hover:scale-105"
                      }`}
                    >
                      <Icon className="w-5 h-5 md:w-6 md:h-6" />
                    </button>

                    {/* Timeline card container */}
                    <div className="flex-1 bg-white border border-slate-200 hover:border-slate-300 rounded-2xl transition-all duration-200 overflow-hidden shadow-sm hover:shadow-md">
                      
                      {/* Summary Header */}
                      <div 
                        onClick={() => toggleExpand(event.id)}
                        className="p-5 md:p-6 cursor-pointer flex justify-between items-start gap-4 select-none"
                      >
                        <div className="space-y-1.5 flex-1 min-w-0">
                          {/* Top row: category and date */}
                          <div className="flex flex-wrap items-center gap-2.5 text-xs">
                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider font-sans border uppercase ${meta.bg}`}>
                              {meta.label}
                            </span>
                            <span className="text-slate-400 flex items-center gap-1 font-mono">
                              <Calendar className="w-3.5 h-3.5 text-slate-300" />
                              {event.date}
                            </span>
                            <span className="text-slate-400 flex items-center gap-1 font-sans">
                              <MapPin className="w-3.5 h-3.5 text-slate-300" />
                              {event.hospital}
                            </span>
                          </div>

                          {/* Clear Name / Title with Status Badges */}
                          {renderClearTitleAndBadge(event)}

                          {/* Hospital & Department info */}
                          <div className="flex items-center gap-2 text-xs text-slate-500">
                            <span className="text-slate-400 font-medium">就诊科室：</span>
                            <span className="px-2 py-0.5 rounded bg-slate-50 border border-slate-150 text-slate-600 font-mono text-[11px]">
                              {event.department}
                            </span>
                          </div>

                          {/* Primary Diagnosis Badged Row */}
                          <div className="flex items-center gap-1.5 mt-2">
                            <span className="text-xs font-bold text-slate-700 shrink-0 bg-slate-100 border border-slate-200/80 px-1.5 py-0.5 rounded">临床诊断：</span>
                            <span className="text-xs text-slate-800 font-semibold truncate select-all">
                              {event.summary}
                            </span>
                          </div>

                        </div>

                        {/* Right Chevron & encryption status */}
                        <div className="flex flex-col items-end gap-3 self-stretch justify-between shrink-0">
                          <span className="flex items-center gap-1 text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200/60 px-2 py-0.5 rounded-lg font-medium">
                            <ShieldCheck className="w-3 h-3 stroke-[2.5]" />
                            已端加密
                          </span>
                          {isExpanded ? (
                            <ChevronUp className="w-5 h-5 text-slate-400 group-hover:text-slate-600 transition-colors" />
                          ) : (
                            <ChevronDown className="w-5 h-5 text-slate-400 group-hover:text-slate-600 transition-colors" />
                          )}
                        </div>
                      </div>

                      {/* Expanded Detail View */}
                      {isExpanded && (
                        <div className="border-t border-slate-100 bg-slate-50/40 p-5 md:p-6 space-y-6">
                          
                          {/* Sub-view rendering based on category */}
                          {event.category === TimelineCategory.LAB && event.labIndicators && (
                            <div>
                              <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">
                                指标检测明细 (Laboratory Test Details)
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {event.labIndicators.map((indicator, idx) => {
                                  const isHigh = indicator.status === "high";
                                  const isLow = indicator.status === "low";
                                  
                                  return (
                                    <div 
                                      key={idx} 
                                      className={`p-3.5 rounded-xl border flex justify-between items-center ${
                                        isHigh 
                                          ? "bg-amber-50/60 border-amber-200" 
                                          : isLow 
                                            ? "bg-blue-50/60 border-blue-200" 
                                            : "bg-white border-slate-200/80 shadow-sm"
                                      }`}
                                    >
                                      <div className="space-y-1">
                                        <div className="flex items-center gap-2">
                                          <span className="text-sm font-bold text-slate-800">{indicator.name}</span>
                                          {indicator.abbr && (
                                            <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                                              {indicator.abbr}
                                            </span>
                                          )}
                                        </div>
                                        <span className="text-xs font-mono text-slate-500 block">
                                          参考区间: {indicator.referenceRange} {indicator.unit}
                                        </span>
                                      </div>

                                      <div className="text-right flex items-center gap-3">
                                        <div className="font-mono">
                                          <span className={`text-base font-bold ${
                                            isHigh ? "text-amber-600" : isLow ? "text-blue-600" : "text-emerald-600"
                                          }`}>
                                            {indicator.value}
                                          </span>
                                          <span className="text-xs text-slate-400 ml-1 font-sans">{indicator.unit}</span>
                                        </div>
                                        
                                        {/* Status Tag */}
                                        {isHigh && (
                                          <span className="w-7 h-7 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                                            <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                                          </span>
                                        )}
                                        {isLow && (
                                          <span className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
                                            <ArrowDownRight className="w-4 h-4 stroke-[2.5]" />
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {event.category === TimelineCategory.OUTPATIENT && (
                            <div className="bg-white border border-slate-200 p-4 rounded-xl space-y-3 shadow-sm">
                              <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                                临床门诊大病历记录 (Clinical Diagnosis Case)
                              </h4>
                              <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap font-mono select-text bg-slate-50 p-3.5 rounded-lg border border-slate-200 shadow-inner">
                                {event.rawText}
                              </p>
                            </div>
                          )}

                          {event.category === TimelineCategory.IMAGING && event.imagingResult && (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="bg-white border border-slate-200 p-4 rounded-xl space-y-2 shadow-sm">
                                <span className="text-xs font-semibold text-slate-500 block">超声/影像所见 (Findings)</span>
                                <p className="text-slate-700 text-sm leading-relaxed font-mono whitespace-pre-wrap select-text">
                                  {event.imagingResult.finding}
                                </p>
                              </div>
                              <div className="bg-amber-50/40 border border-amber-200 p-4 rounded-xl space-y-2 shadow-sm">
                                <span className="text-xs font-semibold text-amber-800 block">提示与诊断意见 (Conclusions)</span>
                                <p className="text-amber-950 text-sm leading-relaxed font-bold font-mono whitespace-pre-wrap select-text">
                                  {event.imagingResult.conclusion}
                                </p>
                              </div>
                            </div>
                          )}

                          {event.category === TimelineCategory.PRESCRIPTION && event.prescriptions && (
                            <div>
                              <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">
                                药方药物清单 (Prescription Med List)
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {event.prescriptions.map((med, idx) => (
                                  <div key={idx} className="bg-white border border-slate-200 p-4 rounded-xl flex justify-between items-start shadow-sm">
                                    <div className="space-y-1.5 flex-1">
                                      <span className="text-sm font-bold text-slate-800 block">{med.drugName}</span>
                                      <span className="text-xs font-mono text-slate-500 block">
                                        用法：{med.dosage}
                                      </span>
                                    </div>
                                    <div className="text-right space-y-1 ml-3 shrink-0">
                                      <span className="text-xs font-mono text-slate-400 block">规格：{med.specification}</span>
                                      <span className="text-xs font-bold font-mono text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded inline-block">
                                        数量: {med.quantity}
                                      </span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* AI Interpretation Panel: 医我智析 */}
                          {event.aiInterpretation && (
                            <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-5 space-y-3 shadow-sm">
                              <div className="flex items-center gap-2">
                                <span className="w-5 h-5 rounded bg-emerald-600 text-white flex items-center justify-center">
                                  <Heart className="w-3.5 h-3.5 fill-current" />
                                </span>
                                <h4 className="text-sm font-bold text-emerald-800">
                                  医我智析 (Interactive AI Health Interpretation)
                                </h4>
                              </div>
                              <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap select-text">
                                {event.aiInterpretation}
                              </p>
                              <div className="text-[10px] text-emerald-600/80 font-mono flex items-center gap-1">
                                <ShieldCheck className="w-3.5 h-3.5" />
                                报告经由本地安全沙箱对大模型接口双向脱敏传输，绝不留存云端
                              </div>
                            </div>
                          )}

                          {/* Bottom controls */}
                          <div className="flex justify-between items-center pt-4 border-t border-slate-100">
                            <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                              <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
                              AES-256 本地文件签名校验：安全、完整
                            </span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                if (confirm("确定要永久从您的本地保险箱中删除该就诊记录吗？删除后不可恢复。")) {
                                  onDeleteEvent(event.id);
                                }
                              }}
                              className="text-xs text-red-500 hover:text-red-700 hover:bg-red-50 border border-transparent hover:border-red-200 px-3 py-1.5 rounded-lg transition-colors cursor-pointer animate-none"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              彻底擦除
                            </button>
                          </div>

                        </div>
                      )}

                    </div>
                  </div>
                );
              })}
            </div>

          </div>
        )}
      </div>

    </div>
  );
}
