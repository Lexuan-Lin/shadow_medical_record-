/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum TimelineCategory {
  OUTPATIENT = "outpatient",     // 门诊病历
  LAB = "lab",                   // 化验单
  IMAGING = "imaging",           // 检查影像 (B超/CT等)
  PRESCRIPTION = "prescription"  // 药方处方
}

export interface LabIndicator {
  name: string;             // 指标名称 (如: 甘油三酯)
  abbr?: string;            // 缩写 (如: TG)
  value: string;            // 检测值 (如: 2.34)
  unit: string;             // 单位 (如: mmol/L)
  referenceRange: string;   // 参考范围 (如: 0.45 - 1.70)
  status: "normal" | "high" | "low"; // 状态: 正常、偏高、偏低
}

export interface PrescriptionItem {
  drugName: string;         // 药品名称
  specification: string;    // 规格 (如: 0.25g * 24s)
  dosage: string;           // 用量 (如: 一次1片，一日3次)
  quantity: string;         // 数量 (如: 2盒)
}

export interface TimelineEvent {
  id: string;
  date: string;             // 发生日期 (YYYY-MM-DD)
  hospital: string;         // 就诊医院
  department: string;       // 科室
  category: TimelineCategory;
  title: string;            // 事件标题
  summary: string;          // 简述/主要诊断
  rawText?: string;         // OCR 原始文本
  labIndicators?: LabIndicator[];
  prescriptions?: PrescriptionItem[];
  imagingResult?: {
    finding: string;        // 检查所见
    conclusion: string;     // 诊断意见
  };
  isEncrypted?: boolean;    // 是否已本地强加密存储
  aiInterpretation?: string; // 医我智析 (AI专家解读)
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}
