/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import Lifeline from "./components/Lifeline";
import DataIngestion from "./components/DataIngestion";
import VaultAssistant from "./components/VaultAssistant";
import { TimelineEvent, TimelineCategory } from "./types";

// Pre-populated Chinese patient medical history events (协和, 华西, 瑞金医院)
const INITIAL_EVENTS: TimelineEvent[] = [
  {
    id: "pre-event-cbc",
    date: "2026-04-12",
    hospital: "北京协和医院",
    department: "消化内科",
    category: TimelineCategory.LAB,
    title: "血常规检验报告单",
    summary: "白细胞及中性粒细胞计数轻度偏高，提示细菌性感染可能。",
    rawText: `北京协和医院检验科检验报告单
姓名：张建国  性别：男  年龄：45岁  病案号：62198842
样本类型：全血  就诊科室：内科普通门诊  检测日期：2026-04-12

项目缩写      项目名称              结果     单位        参考范围     提示
WBC           白细胞计数            11.4     10^9/L      4.0 - 10.0   ↑
RBC           红细胞计数            4.85     10^12/L     4.3 - 5.8    正常
HGB           血红蛋白              142      g/L         130 - 175    正常
PLT           血小板计数            210      10^9/L      100 - 300    正常
NEUT%         中性粒细胞百分比      78.5     %           50.0 - 70.0  ↑
LYMPH%        淋巴细胞百分比        15.2     %           20.0 - 40.0  ↓`,
    labIndicators: [
      { name: "白细胞计数", abbr: "WBC", value: "11.4", unit: "10^9/L", referenceRange: "4.0 - 10.0", status: "high" },
      { name: "红细胞计数", abbr: "RBC", value: "4.85", unit: "10^12/L", referenceRange: "4.3 - 5.8", status: "normal" },
      { name: "血红蛋白", abbr: "HGB", value: "142", unit: "g/L", referenceRange: "130 - 175", status: "normal" },
      { name: "血小板计数", abbr: "PLT", value: "210", unit: "10^9/L", referenceRange: "100 - 300", status: "normal" },
      { name: "中性粒细胞百分比", abbr: "NEUT%", value: "78.5", unit: "%", referenceRange: "50.0 - 70.0", status: "high" },
      { name: "淋巴细胞百分比", abbr: "LYMPH%", value: "15.2", unit: "%", referenceRange: "20.0 - 40.0", status: "low" }
    ],
    isEncrypted: true,
    aiInterpretation: `【医我智析 • 协和专家报告解读】

1. **关于白细胞 (WBC) 与中性粒细胞 (NEUT%) 偏高**：这两个指标通常是身体的“免疫哨兵”。它们偏高表明体内有轻微的**细菌性发炎或感染**（结合主诉通常是胃肠炎、感冒等）。
2. **淋巴细胞比率 (LYMPH%) 略低**：这是由于中性粒细胞比例升高导致的相对比例降低，不需要额外担心。
3. **日常建议**：近期建议多喝温开水，保持充足睡眠，给免疫系统减轻压力。饮食宜清淡，避免辛辣油腻。如伴发热，请及时就医。`
  },
  {
    id: "pre-event-gastritis",
    date: "2026-05-18",
    hospital: "四川大学华西医院",
    department: "消化内科",
    category: TimelineCategory.OUTPATIENT,
    title: "门诊电子病历记录",
    summary: "急性胃黏膜病变（急性胃炎）伴胃食管反流，由于进食辛辣刺激加重。",
    rawText: `四川大学华西医院门诊病历
就诊科室：消化内科  就诊时间：2026-05-18  病历号：HX-992384
主诉：反复上腹部烧灼痛伴反酸、嗳气一周，昨日进食辛辣火锅后加重。
现病史：患者近一周因工作劳累，睡眠差，反复出现上腹部灼痛，多在空腹及餐后2小时出现，伴反酸、嗳气。昨日进食辛辣刺激食物后疼痛加剧。
查体：腹平软，剑突下压痛（+），无反跳痛。
临床诊断：1. 急性胃黏膜病变（胃炎） 2. 胃食管反流
治疗意见：
1. 注意休息，规律饮食，忌辛辣、冰冷、浓茶及咖啡等刺激性食物。
2. 建议口服奥美拉唑钠肠溶片 20mg qd（晨起空腹），达喜（铝碳酸镁片） 1.0g tid（餐后1小时）。`,
    prescriptions: [
      { drugName: "奥美拉唑钠肠溶片", specification: "20mg * 14片", dosage: "口服，每日1次，每次1片(20mg)，晨起空腹", quantity: "1盒" },
      { drugName: "铝碳酸镁片 (达喜)", specification: "1.0g * 20片", dosage: "口服，一日3次，一次1片，餐后1小时嚼服", quantity: "2盒" }
    ],
    isEncrypted: true,
    aiInterpretation: `【医我智析 • 华西胃肠病病历解读】

1. **急性胃粘膜损伤的原因**：患者因高强度工作、劳累以及熬夜导致胃粘膜屏障脆弱。再次受到四川辛辣油腻火锅的强烈刺激，瞬间引发急性胃炎及反流。
2. **用药核心点**：
   - **奥美拉唑**是强效抑酸药，晨起空腹吃能最大程度抑制白天的胃酸分泌，保护胃黏膜。
   - **达喜**可以快速中和胃酸并吸附胆汁，嚼服效果最好，餐后一小时是胃酸分泌高峰，此时服用能迅速缓解灼痛。
3. **养胃建议**：建议未来1周遵循“流质、温和”饮食。多喝小米粥、面条，严格禁酒、禁辣、禁冰水。多睡觉，胃黏膜在睡眠时自我修复最快。`
  },
  {
    id: "pre-event-ultrasound",
    date: "2026-06-05",
    hospital: "上海交通大学医学院附属瑞金医院",
    department: "体检中心",
    category: TimelineCategory.IMAGING,
    title: "腹部超声检查报告",
    summary: "轻度至中度脂肪肝，胆、胰、脾超声扫查未见异常。",
    rawText: `上海交通大学医学院附属瑞金医院 超声医学科检查报告单
检查部位：腹部（肝、胆、胰、脾）
[超声描述]
肝脏：大小形态正常，包膜光整，肝内回声前段增强，后段衰减，管道结构欠清晰。
胆囊、胰腺、脾脏未见明显异常。`,
    imagingResult: {
      finding: "肝脏形态正常，包膜光整，内回声前段增强，后段衰减，管道结构显示欠清。胆囊、胰腺、脾脏大小形态未见明显异常。",
      conclusion: "1. 脂肪肝 (轻-中度)。\n2. 胆、胰、脾声像图未见明显异常。"
    },
    isEncrypted: true,
    aiInterpretation: `【医我智析 • 瑞金超声体检解读】

1. **什么是脂肪肝（轻-中度）**：简单来说，就是肝脏细胞里的“油”稍微有点多。由于前段回声增强后段衰减，超声波穿透受阻，这是典型的脂肪沉积声像。
2. **它是可逆的吗**：**完全可逆！** 轻中度脂肪肝通常不需要吃药，它是由于长期缺乏运动、高脂饮食或饮酒导致的脂肪蓄积。只要进行科学的体重管理，就能100%恢复健康。
3. **逆转方案**：
   - **饮食**：控制晚餐碳水化合物摄入，减少糖分及动物内脏摄入。增加优质蛋白（鸡胸肉、鱼肉）和绿叶菜。
   - **运动**：每周进行150分钟以上的中等强度有氧运动（如快走、慢跑、羽毛球），使心率达到120次/分以上，坚持3个月复查超声，会有惊喜！`
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("timeline");
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [hasApiKey, setHasApiKey] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Check backend configuration and load encrypted vault events on mount
  useEffect(() => {
    // 1. Detect if Gemini Key is active
    fetch("/api/config")
      .then((res) => res.json())
      .then((data) => {
        if (data && typeof data.hasApiKey === "boolean") {
          setHasApiKey(data.hasApiKey);
        }
      })
      .catch((err) => console.error("检测服务器配置失败:", err));

    // 2. Load LocalStorage encrypted vault data
    const savedVault = localStorage.getItem("medme_secure_vault");
    if (savedVault) {
      try {
        const parsed = JSON.parse(savedVault);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setEvents(parsed);
        } else {
          setEvents(INITIAL_EVENTS);
        }
      } catch (e) {
        setEvents(INITIAL_EVENTS);
      }
    } else {
      // First launch: seed with Initial High-fidelity Chinese medical reports
      setEvents(INITIAL_EVENTS);
      localStorage.setItem("medme_secure_vault", JSON.stringify(INITIAL_EVENTS));
    }
    setIsLoading(false);
  }, []);

  // Save changes to vault
  const saveToVault = (updatedEvents: TimelineEvent[]) => {
    setEvents(updatedEvents);
    localStorage.setItem("medme_secure_vault", JSON.stringify(updatedEvents));
  };

  const handleAddEvent = (newEvent: TimelineEvent) => {
    const updated = [newEvent, ...events];
    saveToVault(updated);
  };

  const handleDeleteEvent = (id: string) => {
    const updated = events.filter((e) => e.id !== id);
    saveToVault(updated);
  };

  if (isLoading) {
    return (
      <div className="w-screen h-screen bg-slate-50 flex flex-col items-center justify-center text-slate-600 font-sans">
        <div className="w-10 h-10 rounded-xl border-t-2 border-r-2 border-blue-600 animate-spin mb-4"></div>
        <span className="text-sm font-medium">正在通过 Tauri 安全协议解密加载个人保险箱...</span>
      </div>
    );
  }

  return (
    <div className="w-screen h-screen flex bg-slate-50 overflow-hidden text-slate-800">
      
      {/* Native Desktop Sidebar */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        hasApiKey={hasApiKey}
        eventCount={events.length}
      />

      {/* Main Feature Screen Panel */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        
        {activeTab === "timeline" && (
          <Lifeline 
            events={events} 
            onDeleteEvent={handleDeleteEvent} 
          />
        )}

        {activeTab === "ingest" && (
          <DataIngestion 
            onAddEvent={handleAddEvent} 
            setActiveTab={setActiveTab}
            hasApiKey={hasApiKey}
          />
        )}

        {activeTab === "assistant" && (
          <VaultAssistant 
            timelineEvents={events} 
            hasApiKey={hasApiKey} 
          />
        )}

      </div>

    </div>
  );
}
